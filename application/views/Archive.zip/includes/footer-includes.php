<script type="text/javascript" src="assets/dist/js/jquery-3.4.1.min.js"></script>

<!-- bootstrap -->
<script type="text/javascript" src="assets/dist/js/popper.min.js"></script>
<script type="text/javascript" src="assets/dist/js/bootstrap.min.js"></script>

<!-- owl carousel -->
<script type="text/javascript" src="assets/dist/js/owl.carousel.min.js"></script>

<!-- wow js -->
<script type="text/javascript" src="assets/dist/js/aos.js"></script>

<!-- custom js code -->
<script type="text/javascript" src="assets/dist/js/custom.js"></script>