<header class="login-header">
  <div class="container">
    <div class="header-inner">
      <!-- logo -->
      <a href="http://localhost/realestate-html" class="logo" data-aos="fade-down"> 
        <img src="assets/images/logo.svg" alt="logo" />
      </a>
    </div>
  </div>
</header>
