<header class="session-out">
  <div class="container">
    <div class="header-inner">
      <!-- logo -->
      <a href="http://localhost/realestate-html" class="logo" data-aos="fade-down"> 
        <img src="assets/images/logo.svg" alt="logo" />
      </a>

      <!-- header right -->
      <div class="masthead" data-aos="fade-down" data-aos-delay="200">
        <div class="item">
          <div class="login-btn">
          <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#login-modal">
            Login
          </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>